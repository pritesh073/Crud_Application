package Crud_Application;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final UserDAO userDAO = new UserDAO();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("1. Create User");
            System.out.println("2. Read Users");
            System.out.println("3. Update User");
            System.out.println("4. Delete User");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    userDAO.createUser(name, email);
                    break;
                case 2:
                    List<User> users = userDAO.readUsers();
                    for (User user : users) {
                        System.out.println(user);
                    }
                    break;
                case 3:
                    System.out.print("Enter user ID to update: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new email: ");
                    email = scanner.nextLine();
                    userDAO.updateUser(id, name, email);
                    break;
                case 4:
                    System.out.print("Enter user ID to delete: ");
                    id = scanner.nextInt();
                    userDAO.deleteUser(id);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}

